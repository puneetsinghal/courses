#!/usr/bin/env python

from distutils.core import setup

setup(
    name='DeepRL Homework 1',
    version='1.1',
    description='Library for 10-703 Homework 1',
    packages=['deeprl_hw1'])
